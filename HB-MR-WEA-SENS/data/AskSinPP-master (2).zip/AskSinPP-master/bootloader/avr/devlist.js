
var devlist = {
  "Original" : [
    { "id" : "0002", "name" : "HM-LC-SW1-SM" },
    { "id" : "000A", "name" : "HM-LC-SW2-SM" },
    { "id" : "0003", "name" : "HM-LC-SW4-SM" },
    { "id" : "0005", "name" : "HM-LC-Bl1-FM" },
    { "id" : "001D", "name" : "HM-RC-3" },
    { "id" : "0030", "name" : "HM-SEC-RHS" },
    { "id" : "00C3", "name" : "HM-SEC-RHS-2" }
  ],
  "Homebrew" : [
    { "id" : "F209", "name" : "HB-SEC-RHS-3" },
    { "id" : "F20A", "name" : "HB-LC-Bl1-Velux" }
  ]
};

